import mmcv
#for img in mmcv.scandir('/home/ljr/UDA_for_RS-main/data/potsdam/img_dir/train', 'png', recursive=True):

#for img in mmcv.scandir('/home/ljr/UDA_for_RS-main/data/vaihingen/img_dir/train', 'png', recursive=True):

#/home/ljr/UDA_for_RS-main/data/vaihingen/img_dir/test
#/home/ljr/UDA_for_RS-main/data/vaihingen/img_dir/train
#    print(img)
#3_11_5120_3584_5632_4096.png

import mmcv.utils.path
scandir('/home/ljr/UDA_for_RS-main/data/vaihingen/img_dir/train','png',True,True)

