uda = dict(
    type='NO_UDA',
    blur=True,
    color_jitter_strength=0.2,
    color_jitter_probability=0.2,
    debug_img_interval=1000,
    print_grad_magnitude=False,
)
use_ddp_wrapper = True
